Description:
main agenda of that projecty to make operating system simulization

Setup:
git clone https://github.com/your-username/folder_name.git
run all cpp fiules in ubuntu 

![image](https://github.com/runtime-error786/operating_system_simulation/assets/123109871/86a3bef8-fa66-4e95-9eea-37a1f63948f7)
